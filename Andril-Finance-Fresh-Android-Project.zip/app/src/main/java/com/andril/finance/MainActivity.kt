package com.andril.finance

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.WindowManager
import android.widget.*
import android.text.InputType
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("andril_secure_store", Context.MODE_PRIVATE) }
    private val gold = Color.rgb(198, 164, 104)
    private val dark = Color.rgb(19, 21, 25)
    private var entries = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        if (prefs.getString("pin_hash", null) == null) pinScreen(true) else pinScreen(false)
    }
    private fun hash(pin: String) = java.security.MessageDigest.getInstance("SHA-256")
        .digest(("AndrilFinance|" + pin).toByteArray()).joinToString("") { "%02x".format(it) }

    private fun pinScreen(setup: Boolean) {
        val box = screen(if (setup) "CREATE YOUR PIN" else "WELCOME BACK",
            if (setup) "Create a private 6-digit app PIN." else "Enter your PIN to unlock Andril Finance.")
        val pin = EditText(this).apply { hint = "6-digit PIN"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        box.addView(pin, lp())
        box.addView(button(if (setup) "Create PIN" else "Unlock") {
            val p = pin.text.toString()
            if (setup) {
                if (p.length != 6 || !p.all { it.isDigit() }) toast("Enter exactly 6 digits")
                else { prefs.edit().putString("pin_hash", hash(p)).apply(); dashboard() }
            } else if (hash(p) == prefs.getString("pin_hash", "")) { load(); dashboard() }
            else toast("Incorrect PIN")
        }, lp())
    }
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("andril_finance_aes", null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder("andril_finance_aes",
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return gen.generateKey()
    }
    private fun load() {
        entries = try {
            val iv = android.util.Base64.decode(prefs.getString("iv", "") ?: "", android.util.Base64.DEFAULT)
            val data = android.util.Base64.decode(prefs.getString("data", "") ?: "", android.util.Base64.DEFAULT)
            if (iv.isEmpty() || data.isEmpty()) JSONArray() else {
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
                JSONArray(String(c.doFinal(data), Charsets.UTF_8))
            }
        } catch (_: Exception) { JSONArray() }
    }
    private fun save() {
        try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val bytes = c.doFinal(entries.toString().toByteArray(Charsets.UTF_8))
            prefs.edit().putString("iv", android.util.Base64.encodeToString(c.iv, android.util.Base64.NO_WRAP))
                .putString("data", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)).apply()
        } catch (_: Exception) { toast("Secure save failed") }
    }
    private fun sum(type: String): Double {
        var total = 0.0
        for (i in 0 until entries.length()) if (entries.getJSONObject(i).optString("type") == type)
            total += entries.getJSONObject(i).optDouble("amount")
        return total
    }
    private fun money(n: Double) = NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(n)
    private fun dashboard() {
        val box = screen("ANDRIL FINANCE", "PRIVATE • STORED ON THIS PHONE")
        val inc = sum("INCOME"); val exp = sum("EXPENSE")
        box.addView(label("BALANCE\\n${money(inc-exp)}", 25, gold), lp())
        box.addView(label("Income  ${money(inc)}\\nExpenses  ${money(exp)}", 15, Color.LTGRAY), lp())
        box.addView(button("+ Add income") { add("INCOME") }, lp())
        box.addView(button("+ Add expense") { add("EXPENSE") }, lp())
        box.addView(button("Transactions") { transactions() }, lp())
        box.addView(button("Lock app") { pinScreen(false) }, lp())
        box.addView(label("Records are encrypted locally using Android Keystore (AES-GCM).", 12, Color.LTGRAY), lp())
    }
    private fun add(type: String) {
        val box = screen("ADD $type", "Enter the amount and project or description.")
        val amount = EditText(this).apply { hint = "Amount in ₹"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val note = EditText(this).apply { hint = "Project / description" }
        box.addView(amount, lp()); box.addView(note, lp())
        box.addView(button("Save") {
            val n = amount.text.toString().toDoubleOrNull()
            if (n == null || n <= 0) toast("Enter a valid amount") else {
                entries.put(JSONObject().put("type", type).put("amount", n).put("note", note.text.toString()))
                save(); dashboard()
            }
        }, lp())
        box.addView(button("Cancel") { dashboard() }, lp())
    }
    private fun transactions() {
        val box = screen("TRANSACTIONS", "Your locally saved records")
        if (entries.length() == 0) box.addView(label("No transactions yet.", 15, Color.WHITE), lp())
        for (i in entries.length()-1 downTo 0) {
            val e = entries.getJSONObject(i)
            box.addView(label("${e.optString("type")}  ${money(e.optDouble("amount"))}\\n${e.optString("note")}", 14, Color.WHITE), lp())
        }
        box.addView(button("Back") { dashboard() }, lp())
    }
    private fun screen(title: String, sub: String): LinearLayout {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(26, 38, 26, 26); setBackgroundColor(dark) }
        val scroll = ScrollView(this).apply { addView(root) }; setContentView(scroll)
        root.addView(label(title, 24, gold), lp()); root.addView(label(sub, 13, Color.LTGRAY), lp())
        return root
    }
    private fun label(s: String, size: Float, color: Int) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10)
    }
    private fun button(s: String, f: () -> Unit) = Button(this).apply {
        text = s; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(76, 63, 43)); setOnClickListener { f() }
    }
    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
