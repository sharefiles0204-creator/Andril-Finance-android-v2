# Andril Finance — Fresh Native Android Project

## Upload and build
1. Create a **Private** GitHub repository.
2. Extract this ZIP on your phone.
3. Upload the extracted **contents** to the repository root. Preserve `.github/workflows/android.yml`. Uploading only the ZIP file will not activate the workflow.
4. Open Actions. The build runs on push. When successful, open the run and download the `Andril-Finance-APK` artifact.

## Included in this starter
- Native Android Kotlin application (minimum Android 8 / API 26)
- 6-digit PIN gate
- Income and expense entries with automatic totals and balance
- Local encrypted records using AES-GCM and Android Keystore
- Android backup disabled; screenshots blocked in the app

## Security and feature limitations
This starter stores records only on the device and contains no network or cloud-sync code. The PIN is a basic access gate; it is not a substitute for a strong device lock. The first version does **not** yet include Google Authenticator/TOTP, biometric unlock, project-wise reports, PDF export, or a recovery/backup process. Do not enter important financial records until you have tested the app and established a safe backup plan. If you forget the PIN, this starter has no recovery flow; clearing app data or uninstalling may permanently erase records. Keep the GitHub repository private. The workflow produces a debug APK, not a Play Store release.
